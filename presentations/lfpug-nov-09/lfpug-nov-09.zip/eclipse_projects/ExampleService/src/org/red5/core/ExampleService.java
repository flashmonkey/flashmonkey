package org.red5.core;

public class ExampleService {

	public ExampleService() {
		System.out.println("ExampleService starting");
	}
	
	public int add(int a, int b) {
		return a + b;
	}
}
